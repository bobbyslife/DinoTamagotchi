🦕 DINO TAMAGOTCHI - SUPER EASY INSTALL
======================================

Just double-click: "🦕 Install Dino Tamagotchi.command"

That's it! The installer will:
1. Check if you have Python
2. Install the required packages
3. Create the app in your Applications folder
4. You're ready to go!

REQUIREMENTS:
- macOS 10.15+ 
- Python 3.7+ (installer will help you get this)

NEED HELP?
Visit: https://dino.rest

Have fun! 🦕✨
